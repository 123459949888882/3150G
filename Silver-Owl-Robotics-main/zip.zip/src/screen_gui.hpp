#ifndef SCREEN_GUI_H
#define SCREEN_GUI_H

extern int ASV;

extern void DisplayASL();
extern void DisplayWords();
extern void UpdateDynamic();

#endif
